#!/bin/bash

grep -n --color=auto -A 1 'postulate' *.agda
