The hazelnut-dynamics-agda-1.1 directory contains the Agda mechanization as
described in Sec. 3.4 of the paper.

The hazel directory contains the snapshot of the Hazel implementation, which
implements the user interface features described in Sec. 2.

The README.md file in each of these directories provides more information on
each component of the artifact.
